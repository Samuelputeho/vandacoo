//
//  SEPADebitExampleViewController.h
//  Non-Card Payment Examples
//
//  Created by Cameron Sabol on 10/7/19.
//  Copyright © 2019 Stripe. All rights reserved.
//

#import "PaymentExampleViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SEPADebitExampleViewController : PaymentExampleViewController

@end

NS_ASSUME_NONNULL_END
