//
//  BancontactExampleViewController.h
//  Non-Card Payment Examples
//
//  Created by Vineet Shah on 4/29/20.
//  Copyright © 2020 Stripe. All rights reserved.
//

#import "PaymentExampleViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BancontactExampleViewController : PaymentExampleViewController

@end

NS_ASSUME_NONNULL_END
