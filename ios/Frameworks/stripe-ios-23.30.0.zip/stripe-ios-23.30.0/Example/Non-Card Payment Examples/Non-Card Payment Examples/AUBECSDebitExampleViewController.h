//
//  AUBECSDebitExampleViewController.h
//  Non-Card Payment Examples
//
//  Created by Cameron Sabol on 3/16/20.
//  Copyright © 2020 Stripe. All rights reserved.
//

#import "PaymentExampleViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface AUBECSDebitExampleViewController : PaymentExampleViewController

@end

NS_ASSUME_NONNULL_END
