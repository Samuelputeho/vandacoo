//
//  AccountSessionResponse.swift
//  StripeConnect Example
//
//  Created by Chris Mays on 8/23/24.
//

import Foundation

struct AccountSessionResponse: Codable {
    let clientSecret: String
}
