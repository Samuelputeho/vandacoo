//
//  StripeConnectExampleUITests.swift
//  StripeConnectExampleUITests
//
//  Created by Chris Mays on 8/21/24.
//

import XCTest

final class StripeConnectExampleUITests: XCTestCase {
    func testStub() throws {
        // Delete when tests are added
    }
}
