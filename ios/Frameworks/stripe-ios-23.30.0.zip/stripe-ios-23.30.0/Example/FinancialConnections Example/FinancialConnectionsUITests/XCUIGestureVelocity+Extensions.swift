//
//  XCUIGestureVelocity+Extensions.swift
//  FinancialConnectionsUITests
//
//  Created by Krisjanis Gaidis on 4/2/24.
//

import Foundation
import XCTest

extension XCUIGestureVelocity {
    static let verySlow: XCUIGestureVelocity = XCUIGestureVelocity(300)
}
