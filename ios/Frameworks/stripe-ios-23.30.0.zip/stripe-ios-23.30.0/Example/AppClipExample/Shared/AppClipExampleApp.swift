//
//  AppClipExampleApp.swift
//  Shared
//
//  Created by David Estes on 1/7/22.
//

import SwiftUI

@main
struct AppClipExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
