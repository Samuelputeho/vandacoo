//
//  AnalyticsHelperTests.swift
//  StripeiOS Tests
//
//  Created by Ramon Torres on 2/22/22.
//  Copyright © 2022 Stripe, Inc. All rights reserved.
//

import XCTest

@testable@_spi(STP) import Stripe
@testable@_spi(STP) import StripeCore
@testable@_spi(STP) import StripePayments
@testable@_spi(STP) import StripePaymentSheet
@testable@_spi(STP) import StripePaymentsUI

class AnalyticsHelperTests: XCTestCase {

    func test_getDuration() {
        let (sut, timeReference) = makeSUT()

        sut.startTimeMeasurement(.linkPopup)

        // Advance the clock by 10 seconds.
        timeReference.advanceBy(10)
        XCTAssertEqual(sut.getDuration(for: .linkPopup), 10)

        // Advance the clock by 5 seconds.
        timeReference.advanceBy(5)
        XCTAssertEqual(sut.getDuration(for: .linkPopup), 15)
    }

    func test_getDuration_returnsNilWhenNotStarted() {
        let (sut, _) = makeSUT()
        XCTAssertNil(sut.getDuration(for: .linkPopup))
    }

}

extension AnalyticsHelperTests {

    class MockTimeReference {
        var date = Date()

        func advanceBy(_ timeInterval: TimeInterval) {
            date = date.addingTimeInterval(timeInterval)
        }

        func now() -> Date {
            return date
        }
    }

    func makeSUT() -> (AnalyticsHelper, MockTimeReference) {
        let timeReference = MockTimeReference()
        let helper = AnalyticsHelper(timeProvider: timeReference.now)
        return (helper, timeReference)
    }

}
