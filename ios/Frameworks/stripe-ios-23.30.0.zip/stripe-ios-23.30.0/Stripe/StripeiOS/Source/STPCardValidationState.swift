//
//  STPCardValidationState.swift
//  StripeiOS
//
//  Created by Jack Flintermann on 8/7/15.
//  Copyright (c) 2015 Stripe, Inc. All rights reserved.
//

import Foundation
