//
//  AppDelegate.swift
//  StripeiOSTestHostApp
//
//  Created by Cameron Sabol on 11/4/21.
//  Copyright © 2021 Stripe, Inc. All rights reserved.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }
}
